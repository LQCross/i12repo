//
//  Cocoa+FLEXShortcuts.h
//  Pods
//
//  Created by Tanner on 2/24/21.
//  
//

#import <UIKit/UIKit.h>

@interface UIAlertAction (FLEXShortcuts)
@property (nonatomic, readonly) NSString *flex_styleName;
@end
