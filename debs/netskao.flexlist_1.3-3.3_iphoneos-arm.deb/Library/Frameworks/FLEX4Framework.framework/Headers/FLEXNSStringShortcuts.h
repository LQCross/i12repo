//
//  FLEXNSStringShortcuts.h
//  FLEX
//
//  Created by Tanner on 3/29/21.
//

#import "FLEXShortcutsSection.h"

/// Adds a "UTF-8 Data" shortcut
@interface FLEXNSStringShortcuts : FLEXShortcutsSection

@end
