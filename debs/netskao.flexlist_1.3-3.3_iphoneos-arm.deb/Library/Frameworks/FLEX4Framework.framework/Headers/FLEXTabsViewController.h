//
//  FLEXTabsViewController.h
//  FLEX
//
//  Created by Tanner on 2/4/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXTableViewController.h"

@interface FLEXTabsViewController : FLEXTableViewController

@end
