//
//  FLEXNetworkSettingsController.h
//  FLEXInjected
//
//  Created by Ryan Olson on 2/20/15.
//

#import "FLEXTableViewController.h"

@interface FLEXNetworkSettingsController : FLEXTableViewController

@end
