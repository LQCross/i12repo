//
//  FLEXArgumentInputColorView.h
//  Flipboard
//
//  Created by Ryan Olson on 6/30/14.
//  Copyright (c) 2020 FLEX Team. All rights reserved.
//

#import "FLEXArgumentInputView.h"

@interface FLEXArgumentInputColorView : FLEXArgumentInputView

@end
