//
//  FLEXUIAppShortcuts.h
//  FLEX
//
//  Created by Tanner on 5/25/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXShortcutsSection.h"

@interface FLEXUIAppShortcuts : FLEXShortcutsSection

@end
