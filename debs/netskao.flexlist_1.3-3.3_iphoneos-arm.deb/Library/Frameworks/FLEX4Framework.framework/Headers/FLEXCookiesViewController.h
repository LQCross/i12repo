//
//  FLEXCookiesViewController.h
//  FLEX
//
//  Created by Rich Robinson on 19/10/2015.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXGlobalsEntry.h"
#import "FLEXFilteringTableViewController.h"

@interface FLEXCookiesViewController : FLEXFilteringTableViewController <FLEXGlobalsEntry>

@end
