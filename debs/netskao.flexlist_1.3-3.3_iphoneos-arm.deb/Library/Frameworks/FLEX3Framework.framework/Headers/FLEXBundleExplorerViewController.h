//
//  FLEXBundleExplorerViewController.h
//  FLEX
//
//  Created by Tanner Bennett on 6/13/19.
//  Copyright © 2019 Flipboard. All rights reserved.
//

#import "FLEXObjectExplorerViewController.h"

@interface FLEXBundleExplorerViewController : FLEXObjectExplorerViewController

@end
