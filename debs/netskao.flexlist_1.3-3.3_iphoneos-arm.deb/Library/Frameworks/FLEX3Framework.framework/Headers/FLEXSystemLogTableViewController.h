//
//  FLEXSystemLogTableViewController.h
//  FLEX
//
//  Created by Ryan Olson on 1/19/15.
//  Copyright (c) 2015 f. All rights reserved.
//

#import "FLEXTableViewController.h"
#import "FLEXGlobalsEntry.h"

@interface FLEXSystemLogTableViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
