//
//  FLEXRealmDatabaseManager.h
//  FLEX
//
//  Created by Tim Oliver on 28/01/2016.
//  Copyright © 2016 Realm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FLEXDatabaseManager.h"

@interface FLEXRealmDatabaseManager : NSObject <FLEXDatabaseManager>

@end
