//
//  FLEXColorExplorerViewController.h
//  Flipboard
//
//  Created by Tanner on 10/18/18.
//  Copyright © 2018 Flipboard. All rights reserved.
//

#import "FLEXObjectExplorerViewController.h"

@interface FLEXColorExplorerViewController : FLEXObjectExplorerViewController

@end
